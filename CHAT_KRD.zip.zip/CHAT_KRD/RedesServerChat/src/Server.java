import java.io.*;
import java.net.*;

public class Server {

	public static void main(String[] args) throws Exception {

		String clientSentence;
		String capitalizedSentence;

		ServerSocket welcomeSocket = new ServerSocket(6789);

			System.out.println("To ouvindo!");
			Socket connectionSocket1 = welcomeSocket.accept();
			System.out.println("Alguem se conectou!");
			System.out.println("To ouvindo Denovo");
			Socket connectionSocket2 = welcomeSocket.accept();
			System.out.println("Alguem se conectou!");
			
			BufferedReader inFromClient1 = new BufferedReader(new InputStreamReader(connectionSocket1.getInputStream()));
			DataOutputStream outToClient1 = new DataOutputStream(connectionSocket1.getOutputStream());
			
			BufferedReader inFromClient2 = new BufferedReader(new InputStreamReader(connectionSocket2.getInputStream()));
			DataOutputStream outToClient2 = new DataOutputStream(connectionSocket2.getOutputStream());
		while (true) {
			System.out.println("Esperando do Cliente 1\n");
			clientSentence = inFromClient1.readLine();

			capitalizedSentence = clientSentence.toUpperCase() + "\n";

			outToClient2.writeBytes(capitalizedSentence);
			
			
			System.out.println("Esperando do Cliente 2\n");
			clientSentence = inFromClient2.readLine();

			capitalizedSentence = clientSentence.toUpperCase() + "\n";

			outToClient1.writeBytes(capitalizedSentence);
			
			System.out.println("Saiu!");
		}

	}

}
