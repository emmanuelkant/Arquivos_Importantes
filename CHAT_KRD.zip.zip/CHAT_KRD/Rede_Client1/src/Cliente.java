import java.io.*;
import java.net.*;

public class Cliente {

    public static void main(String[] args) throws Exception {

        String sentence;
        String modifiedSentence;
        
			
        	BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
        	Socket clientSocket = new Socket("10.3.7.148", 6789);
        	DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
        	System.out.println("Voc� esta conectado!");
        	BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        while (true) {
//        	System.out.println("\nSUA VEZ DE ENVIAR");
        	System.out.print("DIGITE SUA MENSAGEM: ");
        	sentence = inFromUser.readLine();
        	outToServer.writeBytes(sentence + '\n');
        	System.out.print("***");
        	modifiedSentence = inFromServer.readLine();
        	System.out.println("\nRom�rio disse: " + modifiedSentence);
//        	clientSocket.close();
			
		}
    }
}